# portalDeVendasAPI
Testes de API do Portal de Vendas utilizando Postman e Newman
